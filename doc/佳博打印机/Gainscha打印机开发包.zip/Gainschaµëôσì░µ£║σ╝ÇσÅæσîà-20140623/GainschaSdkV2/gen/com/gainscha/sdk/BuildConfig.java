/** Automatically generated file. DO NOT MODIFY */
package com.gainscha.sdk;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}
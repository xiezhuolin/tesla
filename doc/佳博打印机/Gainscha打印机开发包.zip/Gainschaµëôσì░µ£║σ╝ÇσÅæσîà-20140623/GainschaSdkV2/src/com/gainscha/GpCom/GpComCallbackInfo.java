package com.gainscha.GpCom;

public class GpComCallbackInfo
{
  public GpCom.DATA_TYPE ReceivedDataType;
}

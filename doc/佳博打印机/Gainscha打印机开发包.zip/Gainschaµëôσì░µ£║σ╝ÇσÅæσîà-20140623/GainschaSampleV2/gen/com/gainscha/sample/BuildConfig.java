/** Automatically generated file. DO NOT MODIFY */
package com.gainscha.sample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}